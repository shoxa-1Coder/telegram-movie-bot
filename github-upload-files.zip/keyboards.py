from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton

def language_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🇺🇿 O'zbek", callback_data="lang:uz"),
            InlineKeyboardButton(text="🇷🇺 Русский", callback_data="lang:ru"),
            InlineKeyboardButton(text="🇬🇧 English", callback_data="lang:en"),
        ]
    ])

def main_keyboard(lang: str):
    labels = {
        "uz": ["🔎 Kino qidirish", "🔥 Mashhur kinolar", "🆕 Yangi kinolar", "🎭 Janrlar", "⭐ Sevimlilar", "ℹ️ Yordam"],
        "ru": ["🔎 Поиск фильма", "🔥 Популярные", "🆕 Новинки", "🎭 Жанры", "⭐ Избранное", "ℹ️ Помощь"],
        "en": ["🔎 Search movie", "🔥 Popular movies", "🆕 New movies", "🎭 Genres", "⭐ Favorites", "ℹ️ Help"],
    }
    rows = labels.get(lang, labels["uz"])
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=rows[0])],
            [KeyboardButton(text=rows[1]), KeyboardButton(text=rows[2])],
            [KeyboardButton(text=rows[3]), KeyboardButton(text=rows[4])],
            [KeyboardButton(text=rows[5])],
        ],
        resize_keyboard=True
    )

def movie_buttons(movie_id: int, legal_watch_url: str, lang: str):
    rows = [
        [InlineKeyboardButton(
            text={"uz":"⭐ Sevimliga","ru":"⭐ В избранное","en":"⭐ Favorite"}[lang],
            callback_data=f"fav:{movie_id}"
        )]
    ]
    if legal_watch_url:
        rows.append([InlineKeyboardButton(
            text={"uz":"▶️ Qonuniy ko‘rish","ru":"▶️ Смотреть легально","en":"▶️ Watch legally"}[lang],
            url=legal_watch_url
        )])
    return InlineKeyboardMarkup(inline_keyboard=rows)

def list_keyboard(items, prefix: str, lang: str):
    buttons = []
    for item in items:
        movie_id, uz, ru, en = item[:4]
        title = {"uz": uz, "ru": ru, "en": en}.get(lang, uz)
        buttons.append([InlineKeyboardButton(text=title[:50], callback_data=f"{prefix}:{movie_id}")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)

def genres_keyboard(genres):
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=f"🎭 {g}", callback_data=f"genre:{g}")]
            for g in genres
        ]
    )

def admin_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Add movie", callback_data="admin:add")],
        [InlineKeyboardButton(text="🗑 Delete movie", callback_data="admin:delete")],
        [InlineKeyboardButton(text="📊 Statistics", callback_data="admin:stats")],
    ])
