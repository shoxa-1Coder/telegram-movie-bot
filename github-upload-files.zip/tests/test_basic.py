import asyncio
from db import init_db, ensure_user, set_language, get_language

async def main():
    await init_db()
    await ensure_user(999999999)
    await set_language(999999999, "uz")
    assert await get_language(999999999) == "uz"
    print("Basic database test passed.")

if __name__ == "__main__":
    asyncio.run(main())
