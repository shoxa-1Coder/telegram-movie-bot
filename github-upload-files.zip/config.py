import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_ID = int(os.getenv("ADMIN_ID", "0") or 0)

# Optional: set REQUIRED_CHANNEL to something like @my_channel.
# Leave empty to disable subscription checking.
REQUIRED_CHANNEL = os.getenv("REQUIRED_CHANNEL", "").strip()
