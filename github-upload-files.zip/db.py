import aiosqlite

DB_PATH = "movies.db"

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            language TEXT NOT NULL DEFAULT 'uz',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """)

        await db.execute("""
        CREATE TABLE IF NOT EXISTS movies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title_uz TEXT NOT NULL,
            title_ru TEXT NOT NULL,
            title_en TEXT NOT NULL,
            description_uz TEXT DEFAULT '',
            description_ru TEXT DEFAULT '',
            description_en TEXT DEFAULT '',
            year INTEGER,
            genre TEXT DEFAULT '',
            rating REAL DEFAULT 0,
            poster_url TEXT DEFAULT '',
            legal_watch_url TEXT DEFAULT '',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """)

        await db.execute("""
        CREATE TABLE IF NOT EXISTS favorites (
            user_id INTEGER NOT NULL,
            movie_id INTEGER NOT NULL,
            PRIMARY KEY (user_id, movie_id)
        )
        """)
        await db.commit()

async def ensure_user(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR IGNORE INTO users(user_id) VALUES (?)",
            (user_id,)
        )
        await db.commit()

async def set_language(user_id: int, language: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO users(user_id, language) VALUES (?, ?) "
            "ON CONFLICT(user_id) DO UPDATE SET language=excluded.language",
            (user_id, language)
        )
        await db.commit()

async def get_language(user_id: int) -> str:
    await ensure_user(user_id)
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT language FROM users WHERE user_id=?", (user_id,))
        row = await cur.fetchone()
        return row[0] if row else "uz"

async def search_movies(query: str, limit: int = 10):
    pattern = f"%{query}%"
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("""
            SELECT id, title_uz, title_ru, title_en, year, genre, rating, poster_url,
                   description_uz, description_ru, description_en, legal_watch_url
            FROM movies
            WHERE title_uz LIKE ? OR title_ru LIKE ? OR title_en LIKE ?
            ORDER BY year DESC, rating DESC
            LIMIT ?
        """, (pattern, pattern, pattern, limit))
        return await cur.fetchall()

async def get_movie(movie_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("""
            SELECT id, title_uz, title_ru, title_en, year, genre, rating, poster_url,
                   description_uz, description_ru, description_en, legal_watch_url
            FROM movies WHERE id=?
        """, (movie_id,))
        return await cur.fetchone()

async def get_popular_movies(limit: int = 10):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("""
            SELECT id, title_uz, title_ru, title_en, year, genre, rating, poster_url
            FROM movies ORDER BY rating DESC, year DESC LIMIT ?
        """, (limit,))
        return await cur.fetchall()

async def get_new_movies(limit: int = 10):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("""
            SELECT id, title_uz, title_ru, title_en, year, genre, rating, poster_url
            FROM movies ORDER BY year DESC, id DESC LIMIT ?
        """, (limit,))
        return await cur.fetchall()

async def get_genres():
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("""
            SELECT DISTINCT genre FROM movies
            WHERE genre != '' ORDER BY genre
        """)
        return [row[0] for row in await cur.fetchall()]

async def movies_by_genre(genre: str, limit: int = 20):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("""
            SELECT id, title_uz, title_ru, title_en, year, genre, rating, poster_url
            FROM movies WHERE genre=? ORDER BY rating DESC, year DESC LIMIT ?
        """, (genre, limit))
        return await cur.fetchall()

async def add_movie(data: dict) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("""
            INSERT INTO movies (
                title_uz, title_ru, title_en,
                description_uz, description_ru, description_en,
                year, genre, rating, poster_url, legal_watch_url
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            data["title_uz"], data["title_ru"], data["title_en"],
            data["description_uz"], data["description_ru"], data["description_en"],
            data["year"], data["genre"], data["rating"],
            data["poster_url"], data["legal_watch_url"]
        ))
        await db.commit()
        return cur.lastrowid

async def delete_movie(movie_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM favorites WHERE movie_id=?", (movie_id,))
        await db.execute("DELETE FROM movies WHERE id=?", (movie_id,))
        await db.commit()

async def toggle_favorite(user_id: int, movie_id: int) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT 1 FROM favorites WHERE user_id=? AND movie_id=?",
            (user_id, movie_id)
        )
        exists = await cur.fetchone()

        if exists:
            await db.execute(
                "DELETE FROM favorites WHERE user_id=? AND movie_id=?",
                (user_id, movie_id)
            )
            await db.commit()
            return False

        await db.execute(
            "INSERT OR IGNORE INTO favorites(user_id, movie_id) VALUES (?, ?)",
            (user_id, movie_id)
        )
        await db.commit()
        return True

async def get_favorites(user_id: int, limit: int = 20):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("""
            SELECT m.id, m.title_uz, m.title_ru, m.title_en, m.year,
                   m.genre, m.rating, m.poster_url
            FROM movies m
            JOIN favorites f ON f.movie_id=m.id
            WHERE f.user_id=?
            ORDER BY m.rating DESC, m.year DESC
            LIMIT ?
        """, (user_id, limit))
        return await cur.fetchall()

async def get_user_count() -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT COUNT(*) FROM users")
        row = await cur.fetchone()
        return int(row[0])
