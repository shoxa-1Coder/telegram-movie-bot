# Telegram Movie Bot

A Telegram movie catalog bot built with Python, aiogram 3, and SQLite.

## Features

- Uzbek / Russian / English language selection
- Movie search
- Popular movies
- New movies
- Genres
- Favorites
- Admin panel
- Add/delete movies
- User statistics
- Optional required-channel subscription check
- Legal viewing URL support
- SQLite database

## 1. Install

```bash
python -m venv .venv
```

Linux/macOS:
```bash
source .venv/bin/activate
```

Windows:
```powershell
.venv\Scripts\activate
```

Then:

```bash
pip install -r requirements.txt
```

## 2. Configure

Copy `.env.example` to `.env` and set:

```env
BOT_TOKEN=your_bot_token
ADMIN_ID=your_telegram_numeric_id
REQUIRED_CHANNEL=
```

Never commit `.env` to GitHub.

## 3. Run

```bash
python bot.py
```

## 4. Admin

Open the bot and send:

```text
/admin
```

Only the Telegram user whose numeric ID is in `ADMIN_ID` can access the admin panel.

The Add Movie flow asks for titles, descriptions, year, genre, rating, poster URL, and a legal viewing URL.

## Important

Do not upload or distribute copyrighted movies without permission. This project is designed as a catalog and can link only to viewing sources that you are authorized to use.

## 24/7 deployment

Run the bot on a server/VPS or another Python-compatible hosting service. Keep the process running with a process manager such as systemd or Supervisor.
