from aiogram import Router, F
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery

from config import ADMIN_ID, REQUIRED_CHANNEL
from db import (
    ensure_user, set_language, get_language, search_movies, get_movie,
    get_popular_movies, get_new_movies, get_genres, movies_by_genre,
    toggle_favorite, get_favorites, add_movie, delete_movie, get_user_count
)
from keyboards import (
    language_keyboard, main_keyboard, movie_buttons, list_keyboard,
    genres_keyboard, admin_keyboard
)

router = Router()

TEXT = {
    "uz": {
        "welcome": "🎬 <b>Kino Bot</b>ga xush kelibsiz!\nTilni tanlang:",
        "menu": "🎬 Kerakli bo‘limni tanlang:",
        "search": "🔎 Kino nomini yozing:",
        "not_found": "❌ Kino topilmadi.",
        "help": "ℹ️ Kino nomini yozib qidiring. Faqat qonuniy ko‘rish havolalari qo‘llab-quvvatlanadi.",
        "favorites": "⭐ Sevimli kinolaringiz:",
        "empty": "Hozircha sevimli kino yo‘q.",
        "added": "⭐ Sevimlilarga qo‘shildi.",
        "removed": "Sevimlilardan olib tashlandi.",
        "sub": "Botdan foydalanish uchun kanalga obuna bo‘ling.",
        "sub_button": "📢 Kanalga o‘tish",
        "check": "✅ Tekshirish",
    },
    "ru": {
        "welcome": "🎬 Добро пожаловать в <b>Кино Бот</b>!\nВыберите язык:",
        "menu": "🎬 Выберите раздел:",
        "search": "🔎 Напишите название фильма:",
        "not_found": "❌ Фильм не найден.",
        "help": "ℹ️ Введите название фильма для поиска. Поддерживаются только легальные ссылки.",
        "favorites": "⭐ Ваши избранные фильмы:",
        "empty": "Избранных фильмов пока нет.",
        "added": "⭐ Добавлено в избранное.",
        "removed": "Удалено из избранного.",
        "sub": "Чтобы пользоваться ботом, подпишитесь на канал.",
        "sub_button": "📢 Открыть канал",
        "check": "✅ Проверить",
    },
    "en": {
        "welcome": "🎬 Welcome to <b>Movie Bot</b>!\nChoose your language:",
        "menu": "🎬 Choose a section:",
        "search": "🔎 Enter a movie title:",
        "not_found": "❌ Movie not found.",
        "help": "ℹ️ Enter a movie title to search. Only legal viewing links are supported.",
        "favorites": "⭐ Your favorite movies:",
        "empty": "You have no favorite movies yet.",
        "added": "⭐ Added to favorites.",
        "removed": "Removed from favorites.",
        "sub": "Please subscribe to the channel to use the bot.",
        "sub_button": "📢 Open channel",
        "check": "✅ Check",
    }
}

class AddMovie(StatesGroup):
    title_uz = State()
    title_ru = State()
    title_en = State()
    description_uz = State()
    description_ru = State()
    description_en = State()
    year = State()
    genre = State()
    rating = State()
    poster_url = State()
    legal_watch_url = State()

class DeleteMovie(StatesGroup):
    movie_id = State()

async def is_subscribed(bot, user_id: int) -> bool:
    if not REQUIRED_CHANNEL:
        return True
    try:
        member = await bot.get_chat_member(REQUIRED_CHANNEL, user_id)
        return member.status in {"creator", "administrator", "member"}
    except Exception:
        return False

async def send_movie(message: Message, movie, lang: str):
    (
        movie_id, title_uz, title_ru, title_en, year, genre, rating, poster_url,
        desc_uz, desc_ru, desc_en, legal_watch_url
    ) = movie

    title = {"uz": title_uz, "ru": title_ru, "en": title_en}[lang]
    desc = {"uz": desc_uz, "ru": desc_ru, "en": desc_en}[lang]

    text = (
        f"🎬 <b>{title}</b>\n"
        f"📅 {year or '-'}\n"
        f"🎭 {genre or '-'}\n"
        f"⭐ {rating or 0}\n\n"
        f"{desc or ''}"
    )

    kb = movie_buttons(movie_id, legal_watch_url, lang)
    if poster_url:
        try:
            await message.answer_photo(poster_url, caption=text, reply_markup=kb)
            return
        except Exception:
            pass
    await message.answer(text, reply_markup=kb)

@router.message(CommandStart())
async def start(message: Message):
    await ensure_user(message.from_user.id)
    await message.answer(TEXT["uz"]["welcome"], reply_markup=language_keyboard())

@router.callback_query(F.data.startswith("lang:"))
async def choose_language(callback: CallbackQuery):
    lang = callback.data.split(":")[1]
    await set_language(callback.from_user.id, lang)
    await callback.message.answer(TEXT[lang]["menu"], reply_markup=main_keyboard(lang))
    await callback.answer()

@router.message(Command("admin"))
async def admin(message: Message):
    if message.from_user.id != ADMIN_ID:
        await message.answer("Access denied.")
        return
    await message.answer("🛠 Admin panel", reply_markup=admin_keyboard())

@router.callback_query(F.data == "admin:add")
async def admin_add(callback: CallbackQuery, state: FSMContext):
    if callback.from_user.id != ADMIN_ID:
        await callback.answer("Access denied.", show_alert=True)
        return
    await state.set_state(AddMovie.title_uz)
    await callback.message.answer("Send Uzbek title:")
    await callback.answer()

@router.message(AddMovie.title_uz)
async def add_title_uz(message: Message, state: FSMContext):
    await state.update_data(title_uz=message.text)
    await state.set_state(AddMovie.title_ru)
    await message.answer("Send Russian title:")

@router.message(AddMovie.title_ru)
async def add_title_ru(message: Message, state: FSMContext):
    await state.update_data(title_ru=message.text)
    await state.set_state(AddMovie.title_en)
    await message.answer("Send English title:")

@router.message(AddMovie.title_en)
async def add_title_en(message: Message, state: FSMContext):
    await state.update_data(title_en=message.text)
    await state.set_state(AddMovie.description_uz)
    await message.answer("Send Uzbek description:")

@router.message(AddMovie.description_uz)
async def add_desc_uz(message: Message, state: FSMContext):
    await state.update_data(description_uz=message.text)
    await state.set_state(AddMovie.description_ru)
    await message.answer("Send Russian description:")

@router.message(AddMovie.description_ru)
async def add_desc_ru(message: Message, state: FSMContext):
    await state.update_data(description_ru=message.text)
    await state.set_state(AddMovie.description_en)
    await message.answer("Send English description:")

@router.message(AddMovie.description_en)
async def add_desc_en(message: Message, state: FSMContext):
    await state.update_data(description_en=message.text)
    await state.set_state(AddMovie.year)
    await message.answer("Send release year (example: 2025):")

@router.message(AddMovie.year)
async def add_year(message: Message, state: FSMContext):
    try:
        year = int(message.text)
    except ValueError:
        await message.answer("Please send a number, for example 2025.")
        return
    await state.update_data(year=year)
    await state.set_state(AddMovie.genre)
    await message.answer("Send genre (example: Action):")

@router.message(AddMovie.genre)
async def add_genre(message: Message, state: FSMContext):
    await state.update_data(genre=message.text)
    await state.set_state(AddMovie.rating)
    await message.answer("Send rating from 0 to 10:")

@router.message(AddMovie.rating)
async def add_rating(message: Message, state: FSMContext):
    try:
        rating = float(message.text)
        if not 0 <= rating <= 10:
            raise ValueError
    except ValueError:
        await message.answer("Send a number from 0 to 10.")
        return
    await state.update_data(rating=rating)
    await state.set_state(AddMovie.poster_url)
    await message.answer("Send poster URL, or '-' if none:")

@router.message(AddMovie.poster_url)
async def add_poster(message: Message, state: FSMContext):
    await state.update_data(poster_url="" if message.text.strip() == "-" else message.text.strip())
    await state.set_state(AddMovie.legal_watch_url)
    await message.answer("Send legal viewing URL, or '-' if none:")

@router.message(AddMovie.legal_watch_url)
async def add_legal_url(message: Message, state: FSMContext):
    data = await state.get_data()
    data["legal_watch_url"] = "" if message.text.strip() == "-" else message.text.strip()
    movie_id = await add_movie(data)
    await state.clear()
    await message.answer(f"✅ Movie added successfully. ID: {movie_id}")

@router.callback_query(F.data == "admin:stats")
async def admin_stats(callback: CallbackQuery):
    if callback.from_user.id != ADMIN_ID:
        await callback.answer("Access denied.", show_alert=True)
        return
    count = await get_user_count()
    await callback.message.answer(f"📊 Users: <b>{count}</b>")
    await callback.answer()

@router.callback_query(F.data == "admin:delete")
async def admin_delete_start(callback: CallbackQuery, state: FSMContext):
    if callback.from_user.id != ADMIN_ID:
        await callback.answer("Access denied.", show_alert=True)
        return
    await state.set_state(DeleteMovie.movie_id)
    await callback.message.answer("Send movie ID to delete:")
    await callback.answer()

@router.message(DeleteMovie.movie_id)
async def admin_delete(message: Message, state: FSMContext):
    if message.from_user.id != ADMIN_ID:
        await state.clear()
        return
    try:
        movie_id = int(message.text)
    except ValueError:
        await message.answer("Movie ID must be a number.")
        return
    await delete_movie(movie_id)
    await state.clear()
    await message.answer("🗑 Movie deleted.")

@router.message(F.text)
async def text_router(message: Message):
    lang = await get_language(message.from_user.id)
    text = message.text.strip()

    if not await is_subscribed(message.bot, message.from_user.id):
        await message.answer(TEXT[lang]["sub"])
        return

    labels = {
        "uz": {
            "search": "🔎 Kino qidirish", "popular": "🔥 Mashhur kinolar",
            "new": "🆕 Yangi kinolar", "genres": "🎭 Janrlar",
            "favorites": "⭐ Sevimlilar", "help": "ℹ️ Yordam"
        },
        "ru": {
            "search": "🔎 Поиск фильма", "popular": "🔥 Популярные",
            "new": "🆕 Новинки", "genres": "🎭 Жанры",
            "favorites": "⭐ Избранное", "help": "ℹ️ Помощь"
        },
        "en": {
            "search": "🔎 Search movie", "popular": "🔥 Popular movies",
            "new": "🆕 New movies", "genres": "🎭 Genres",
            "favorites": "⭐ Favorites", "help": "ℹ️ Help"
        }
    }[lang]

    if text == labels["search"]:
        await message.answer(TEXT[lang]["search"])
        return

    if text == labels["popular"]:
        movies = await get_popular_movies()
        if not movies:
            await message.answer(TEXT[lang]["not_found"])
            return
        await message.answer("🔥", reply_markup=list_keyboard(movies, "movie", lang))
        return

    if text == labels["new"]:
        movies = await get_new_movies()
        if not movies:
            await message.answer(TEXT[lang]["not_found"])
            return
        await message.answer("🆕", reply_markup=list_keyboard(movies, "movie", lang))
        return

    if text == labels["genres"]:
        genres = await get_genres()
        if not genres:
            await message.answer(TEXT[lang]["not_found"])
            return
        await message.answer("🎭", reply_markup=genres_keyboard(genres))
        return

    if text == labels["favorites"]:
        movies = await get_favorites(message.from_user.id)
        if not movies:
            await message.answer(TEXT[lang]["empty"])
            return
        await message.answer(TEXT[lang]["favorites"], reply_markup=list_keyboard(movies, "movie", lang))
        return

    if text == labels["help"]:
        await message.answer(TEXT[lang]["help"])
        return

    results = await search_movies(text)
    if not results:
        await message.answer(TEXT[lang]["not_found"])
        return
    await message.answer("🔎", reply_markup=list_keyboard(results, "movie", lang))

@router.callback_query(F.data.startswith("movie:"))
async def movie_callback(callback: CallbackQuery):
    movie_id = int(callback.data.split(":")[1])
    movie = await get_movie(movie_id)
    if not movie:
        await callback.answer("Movie not found.", show_alert=True)
        return
    lang = await get_language(callback.from_user.id)
    await send_movie(callback.message, movie, lang)
    await callback.answer()

@router.callback_query(F.data.startswith("fav:"))
async def favorite_callback(callback: CallbackQuery):
    movie_id = int(callback.data.split(":")[1])
    lang = await get_language(callback.from_user.id)
    added = await toggle_favorite(callback.from_user.id, movie_id)
    await callback.answer(TEXT[lang]["added"] if added else TEXT[lang]["removed"], show_alert=True)

@router.callback_query(F.data.startswith("genre:"))
async def genre_callback(callback: CallbackQuery):
    genre = callback.data.split(":", 1)[1]
    lang = await get_language(callback.from_user.id)
    movies = await movies_by_genre(genre)
    if not movies:
        await callback.answer(TEXT[lang]["not_found"], show_alert=True)
        return
    await callback.message.answer(f"🎭 {genre}", reply_markup=list_keyboard(movies, "movie", lang))
    await callback.answer()
