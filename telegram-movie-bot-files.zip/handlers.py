from aiogram import Router, F
from aiogram.filters import Command, CommandStart
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder

from config import ADMIN_ID
from database import save_user, set_language, search_movies, add_movie

router = Router()

TEXT = {
    "uz": {
        "welcome": "🎬 Kino botga xush kelibsiz! Tilni tanlang:",
        "menu": "Asosiy menyu:",
        "search": "🔎 Kino nomini yozing:",
        "not_found": "Kino topilmadi.",
        "help": "Kino nomini yozib yuboring va bot qidiradi.",
    },
    "ru": {
        "welcome": "🎬 Добро пожаловать! Выберите язык:",
        "menu": "Главное меню:",
        "search": "🔎 Введите название фильма:",
        "not_found": "Фильм не найден.",
        "help": "Отправьте название фильма для поиска.",
    },
    "en": {
        "welcome": "🎬 Welcome! Choose your language:",
        "menu": "Main menu:",
        "search": "🔎 Enter a movie title:",
        "not_found": "Movie not found.",
        "help": "Send a movie title to search.",
    },
}

def language_keyboard():
    kb = InlineKeyboardBuilder()
    kb.button(text="🇺🇿 Uzbek", callback_data="lang:uz")
    kb.button(text="🇷🇺 Русский", callback_data="lang:ru")
    kb.button(text="🇬🇧 English", callback_data="lang:en")
    kb.adjust(1)
    return kb.as_markup()

def menu_keyboard():
    kb = InlineKeyboardBuilder()
    kb.button(text="🔎 Search", callback_data="search")
    kb.button(text="ℹ️ Help", callback_data="help")
    kb.adjust(1)
    return kb.as_markup()

@router.message(CommandStart())
async def start(message: Message):
    await save_user(message.from_user.id)
    await message.answer(TEXT["uz"]["welcome"], reply_markup=language_keyboard())

@router.callback_query(F.data.startswith("lang:"))
async def choose_language(callback: CallbackQuery):
    language = callback.data.split(":")[1]
    await set_language(callback.from_user.id, language)
    await callback.message.edit_text(
        TEXT[language]["menu"],
        reply_markup=menu_keyboard()
    )
    await callback.answer()

@router.callback_query(F.data == "search")
async def search_button(callback: CallbackQuery):
    await callback.message.answer("🔎 Kino nomini yuboring:")
    await callback.answer()

@router.callback_query(F.data == "help")
async def help_button(callback: CallbackQuery):
    await callback.message.answer(TEXT["uz"]["help"])
    await callback.answer()

@router.message(Command("addmovie"))
async def add_movie_command(message: Message):
    if message.from_user.id != ADMIN_ID:
        return await message.answer("⛔ Siz admin emassiz.")

    await message.answer(
        "Format:\nNomi | Yil | Janr | Tavsif | Poster URL | Watch URL"
    )

@router.message()
async def movie_search(message: Message):
    results = await search_movies(message.text.strip())

    if not results:
        return await message.answer("Kino topilmadi.")

    for movie in results:
        movie_id, title, year, genre, description, poster_url, watch_url = movie
        text = f"🎬 {title}\n📅 {year}\n🎭 {genre}\n\n{description or ''}"
        if watch_url:
            text += f"\n\n▶️ Tomosha qilish: {watch_url}"

        if poster_url:
            await message.answer_photo(photo=poster_url, caption=text)
        else:
            await message.answer(text)
