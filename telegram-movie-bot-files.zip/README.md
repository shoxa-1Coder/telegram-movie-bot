# Telegram Movie Bot

## Install

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

On Windows:

```bash
.venv\Scripts\activate
pip install -r requirements.txt
```

## Configure

Copy `.env.example` to `.env` and add:

```env
BOT_TOKEN=your_bot_token
ADMIN_ID=your_telegram_user_id
```

## Run

```bash
python bot.py
```

## Add movies

The `/addmovie` command is reserved for the admin. The current version includes the command placeholder; movie records can be added through the database or an admin form in the next version.
