import aiosqlite

DB_NAME = "movies.db"

async def init_db():
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            language TEXT DEFAULT 'uz'
        )
        """)
        await db.execute("""
        CREATE TABLE IF NOT EXISTS movies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            year INTEGER,
            genre TEXT,
            description TEXT,
            poster_url TEXT,
            watch_url TEXT
        )
        """)
        await db.commit()

async def save_user(user_id: int, language: str = "uz"):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute(
            "INSERT OR IGNORE INTO users(id, language) VALUES (?, ?)",
            (user_id, language)
        )
        await db.commit()

async def set_language(user_id: int, language: str):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute(
            "UPDATE users SET language=? WHERE id=?",
            (language, user_id)
        )
        await db.commit()

async def search_movies(text: str):
    async with aiosqlite.connect(DB_NAME) as db:
        cursor = await db.execute(
            """SELECT id, title, year, genre, description, poster_url, watch_url
               FROM movies WHERE title LIKE ? ORDER BY id DESC LIMIT 10""",
            (f"%{text}%",)
        )
        return await cursor.fetchall()

async def add_movie(title, year, genre, description, poster_url, watch_url):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute(
            """INSERT INTO movies
            (title, year, genre, description, poster_url, watch_url)
            VALUES (?, ?, ?, ?, ?, ?)""",
            (title, year, genre, description, poster_url, watch_url)
        )
        await db.commit()
